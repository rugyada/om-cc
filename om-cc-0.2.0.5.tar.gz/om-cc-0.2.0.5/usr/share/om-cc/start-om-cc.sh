 
python bigbashview.py -s 870x520 -c -i /usr/share/icons/openmandriva.svg index.sh.htm 2> /dev/null;